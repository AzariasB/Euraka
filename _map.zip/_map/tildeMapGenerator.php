<?php

/* Tilde map generator
   ---------------
   Type de case Code html

    Case Mur Entrée / sortie    b00a0a

    Case « entrée-Halo 04 » (droite)    e76c20
    Case « entrée-Halo 01 » (bas)   e500b7
    Case « entrée-Halo 02 » (gauche)    0b4444
    Case « entrée-Halo 03 » (haut)  643315
    Case bordure Sortie « entrée halo 04 » droite   8b3908
    Case bordure Sortie « entrée-Halo 01 » (bas)    ff9d62
    Case bordure Sortie « entrée halo 02 » gauche   b7e500
    Case bordure Sortie « entrée halo 03 » haut 487734
    Case bordure    585151
    Case obstacle Mur   0
    Case sol    ffffff

    Case obstacle et interaction Paille e7eb20
    Case obstacle et interaction ennemi e11212
    Case interaction piège  20c4be

    Case interaction rayon de soleil    54cd25
    Case interaction bonus Kickette a7a0a0

    Sol ou paille   fdff68
    Sol ou rayon de soleil  8cfd5f
    Sol ou piège    84fffb
    Sol ou kickette d7c8c8
    Sol ou tout (paille, soleil, piege ou ennemi)   f9e613

    Piège ou paille 0019ed

    Piege ou ennemi f44545

    Ennemi ou sol   f84573
    Ennemi ou Kickette  b16377


    TOTAL SOLEIL
    TOTAL PAILLE
    TOTAL PIEGES
    TOTAL ENNEMI


    TOTAL DE CASES AVEC INTERACTION / NBRE CASE TOTAL


    "ATTENTION : DANS LE CAS D'UNE PROPOSITION OU SOL N'EST PAS PRPOSE,
    LORSQUE LE NOMBRE D'ENNEMI, PAILLE, SOLEIL, PIEGE OU KICKETTE A FINI D'ETRE DISTRIBUE SUR LES DIFFERENTES CASES
    OU ILS SONT SUSCEPTIBLES D'APPARAITRE, LE RESTE DES CASES DEVIENNENT DES CASES « SOL »."

*/


ini_set('memory_limit', '2048M');

class makeBitmap
{
    public $tileSize;
    public $tileHalf;
    public $src;
    public $imgSize;
    public $imgPixel;
    public $width;
    public $height;

    public $grid;
    public $terrainPointStart;

    function init()
    {
        $this->entree = false;
        $this->sortie = false;

        // Full
        // // $type : map | kaode | starter
        // $this->type = 'kaode';
        // $this->src  = 'demo-kaodes.png';
        // $this->launchMap();
        // $this->type = 'map';
        // $this->src  = 'demo.png';
        // $this->launchMap();
        // $this->saveFile();
        // $this->type = 'starter';
        // $this->src  = 'demo-starter.png';
        // FIN full
        $this->type = 'map';
        $tabMap = array(
            // 'tuto.png',
            'grotte1-1a.png',
            // 'grotte1-2a.png',
            // 'pyramide2-1a.png',
            // 'pyramide2-2a.png'
        );

        foreach ($tabMap as $map) {
                $this->src  = $map;
                $this->run();
                $this->saveFile();
        }

        return;
    }

    function run()
    {
        $this->grid              = array();
        $this->terrainPointStart = array();

        print PHP_EOL;
        print 'Initialisation du traitement';

        $this->tileSize = 40;
        $this->tileHalf = floor($this->tileSize / 2);

        $this->launchMap();
    }

    function launchMap()
    {
        $this->imgSize = getimagesize($this->src);
        $this->imgPixel = $this->getRessource();
        $this->width = $this->imgSize[0];
        $this->height = $this->imgSize[1];

        print PHP_EOL;
        print '  -  Analyse des pixels de la map : ' . $this->src;

        $i = $this->tileHalf;
        $j = $this->tileHalf;
        $lastPercent = null;

        $i = $this->tileHalf;
        $j = $this->tileHalf;
        $lastPercent = null;

        for ($i;$i < $this->height;$i+= $this->tileSize)
        {
            for ($j;$j < $this->width;$j+= $this->tileSize)
            {
                $this->processPixel($j, $i);
            }
            $j = $this->tileHalf;

            $percent = floor($i / ($this->height - $this->tileHalf) * 100);
            if ($percent !== $lastPercent && $percent % 10 === 0)
            {
                print PHP_EOL . '      ' . $percent . '%';
                $lastPercent = $percent;
            }
        }

        print PHP_EOL . '      100%' . PHP_EOL . PHP_EOL;
        print 'Fin de l\'analyse de la map : ' . $this->src . PHP_EOL;
        print 'Entrée : ' . $this->entree . PHP_EOL;
        print 'Sortie : ' . $this->sortie . PHP_EOL;

        return;
    }

    function getRessource()
    {
        switch (strtolower(pathinfo($this->src, PATHINFO_EXTENSION)))
        {
            case 'jpeg':
            case 'jpg':
                return imagecreatefromjpeg($this->src);
            break;
            case 'png':
                return imagecreatefrompng($this->src);
            break;
            case 'gif':
                return imagecreatefromgif($this->src);
            break;
            default:
                throw new InvalidArgumentException('File "' . $this->src . '" is not valid jpg, png or gif image.');
            break;
        }

        return;
    }

    function processPixel($i, $j)
    {
        $tabUnknowHexa = array();
        $hex = $this->getHex($i, $j);
        $x = $this->pixelToTile($i);
        $y = $this->pixelToTile($j);

        $id = null;

        switch ($hex)
        {
            case '#ffffff':
                // sol
                $id = 1;
            break;
            case '#b00a0a':
                // Case Mur Entrée
                $id = 2;
            break;
            case '#b00a0a':
                // Case Mur Sortie
                $id = 3;
            break;
            case '#e76c20':
            case '#e500b7':
            case '#0b4444':
            case '#643315':
                // Case sol lumineuse entrée
                $id = 4;
                $this->entree = true;
            break;
            case '#8b3908':
            case '#ff9d62':
            case '#b7e500':
            case '#487734':
                // Case sol lumineuse sortie
                $id = 5;
                $this->sortie = true;
            break;
            case '#585151':
                // Case bordure
                $id = 6;
            break;
            case '#e7eb20':
                // paille
                $id = 7;
            break;
            case '#e11212':
                // ennemi
                $id = 8;
            break;
            case '#20c4be':
                // piege
                $id = 9;
            break;
            case '#54cd25':
                // soleil
                $id = 10;
            break;
            case '#a7a0a0':
                // kikette
                $id = 11;
            break;
            case '#fdff68':
                // Sol ou paille
                $id = 12;
            break;
            case '#8cfd5f':
                // Sol ou rayon de soleil
                $id = 13;
            break;
            case '#84fffb':
                // Sol ou piège
                $id = 14;
            break;
            case '#d7c8c8':
                // Sol ou kickette
                $id = 15;
            break;
            case '#0019ed':
                // Piège ou paille
                $id = 16;
            break;
            case '#f44545':
                // Piege ou ennemi
                $id = 17;
            break;
            case '#f84573':
                // Ennemi ou sol
                $id = 18;
            break;
            case '#b16377':
                // Ennemi ou Kickette
                $id = 19;
            break;
            default:
                // Wall
                $tabUnknowHexa[] = str_replace('#', '', $hex);
                $id = 0;
            break;
        }

        $tabUnknowHexa = array_unique($tabUnknowHexa);
        if (count($tabUnknowHexa) > 1)
        {
            print 'Hexa inconnu : ' . PHP_EOL;
            foreach ($tabUnknowHexa as $hex)
            {
                print $hex . PHP_EOL;
            }
        }

        return $this->addInArray($id, $x, $y);
    }

    function getHex($i, $j)
    {

        $rgb = imagecolorat($this->imgPixel, $i, $j);
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;

        $hex = '#';
        $hex.= str_pad(dechex($r) , 2, '0', STR_PAD_LEFT);
        $hex.= str_pad(dechex($g) , 2, '0', STR_PAD_LEFT);
        $hex.= str_pad(dechex($b) , 2, '0', STR_PAD_LEFT);

        return $hex;
    }

    function pixelToTile($pixel)
    {
        return floor($pixel / $this->tileSize);
    }

    function addInArray($id, $x, $y)
    {
        if ($this->type === 'starter')
        {
            $this->addTerrainPointStart($id, $x, $y);
        }
        else
        {
            $this->addPointTerrain($x, $y, $id);
        }

        return;
    }

    function addTerrainPointStart($terrain, $x, $y)
    {

        // pas de start dans la mer
        if ($terrain === 'mer')
        {
            return false;
        }

        $terrain = str_replace(array(
            'jungle',
            'cote'
        ) , array(
            'foret',
            'ile'
        ) , $terrain);

        if (!isset($this->terrainPointStart[$terrain]))
        {
            $this->terrainPointStart[$terrain] = array();
        }

        array_push($this->terrainPointStart[$terrain], array(
            $x,
            $y
        ));

        return;
    }

    function addPointTerrain($y, $x, $id)
    {
        if (!isset($this->grid[$x]))
        {
            $this->grid[$x] = array();
        }
        if (!isset($this->grid[$x][$y]))
        {
            $this->grid[$x][$y] = array();
        }

        $letter = '';
        if ($this->type === 'map')
        {
            $letter = 't';
        }
        else if ($this->type === 'kaode')
        {
            $letter = 'k';
        }

        $this->grid[$x][$y] = array_merge($this->grid[$x][$y], array(
            $letter => $id
        ));

        // DEBUG Mode grid
        // $this->grid[$x][$y] = $id;

        return null;
    }

    function saveFile()
    {
        print '  -  Sauvegarde des fichiers DATA en cours...';
        $folder   = 'app/data/stages';
        $filename = pathinfo($this->src, PATHINFO_FILENAME);
        $tab      = json_encode($this->grid);

        if ($this->type === 'starter')
        {
            $tab = json_encode($this->terrainPointStart);
        }

        $fp = fopen($folder . $filename . '.js', 'w');
        fwrite($fp, 'module.exports = {"data": ');
        fwrite($fp, $tab);
        fwrite($fp, '};');
        fclose($fp);

        print ' 100%' . PHP_EOL;
        print 'Finished' . PHP_EOL . PHP_EOL;

        return;
    }
}

$makeBitmap = new makeBitmap();
$makeBitmap->init();
